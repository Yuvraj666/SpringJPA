export class Group {
    public groupId:number;
    public groupName:string;
    public description:string;
}

package com.cg.adb.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.adb.dao.ContactRepository;
import com.cg.adb.entity.ContactEntity;
import com.cg.adb.exception.AdbException;
import com.cg.adb.model.ContactModel;

@Service
public class ContactServiceImpl implements ContactService{

	@Autowired
	private ContactRepository contactRepo;
	
	@Override
	public ContactModel add(ContactModel contact) throws AdbException {		
		return new ContactModel(contactRepo.save(new ContactEntity(contact)));
	}

	@Override
	public ContactModel save(ContactModel contact) throws AdbException {

		ContactModel model=null;
		
		if(!contactRepo.existsById(contact.getContactId())) {
			throw new AdbException("Contact#"+contact.getContactId()+" not found");
		}
		
		model = new ContactModel(contactRepo.save(new ContactEntity(contact)));
		
		return model;
	}

	@Override
	public void delete(Long contactId) throws AdbException {
		
		if(!contactRepo.existsById(contactId)) {
			throw new AdbException("Contact#"+contactId+" not found");
		}
		
		contactRepo.deleteById(contactId);
		
		
	}

	@Override
	public ContactModel findById(Long contactId) {
		Optional<ContactEntity> entity = contactRepo.findById(contactId);
		return entity.isPresent()?new ContactModel(entity.get()):null;
	}

	@Override
	public List<ContactModel> findAll() {
		List<ContactModel> models=null;
		
		List<ContactEntity> entities = contactRepo.findAll();
		
		if(null!=entities && entities.size()>0) {
			models=new ArrayList<ContactModel>();
			for(ContactEntity entity:entities) {
				models.add(new ContactModel(entity));
			}
		}
		
		return models;
	}

}

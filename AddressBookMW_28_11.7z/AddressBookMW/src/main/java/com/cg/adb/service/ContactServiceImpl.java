package com.cg.adb.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.adb.dao.ContactRepository;
import com.cg.adb.dao.GroupRepository;
import com.cg.adb.entity.ContactEntity;
import com.cg.adb.exception.AdbException;
import com.cg.adb.model.ContactModel;
import com.cg.adb.model.GroupStatistics;

@Service
public class ContactServiceImpl implements ContactService {

	@Autowired
	private ContactRepository contactRepo;

	@Autowired
	private GroupRepository grpRepo;

	private ContactModel valueOf(ContactEntity entity) {
		ContactModel model = new ContactModel();

		model.setContactId(entity.getContactId());
		model.setFirstName(entity.getFirstName());
		model.setMiddleName(entity.getMiddleName());
		model.setLastName(entity.getLastName());
		model.setGender(entity.getGender());
		model.setDateOfBirth(entity.getDateOfBirth());
		model.setMobileNumber(entity.getMobileNumber());
		model.setMailId(entity.getMailId());
		model.setWhatsAppNumber(entity.getWhatsAppNumber());
		model.setFaceBookId(entity.getFaceBookId());
		if (entity.getGroup() != null) {
			model.setGroupName(entity.getGroup().getGroupName());
		}
		return model;
	}

	private ContactEntity valueOf(ContactModel model) {
		ContactEntity entity = new ContactEntity();

		entity.setContactId(model.getContactId());
		entity.setFirstName(model.getFirstName());
		entity.setMiddleName(model.getMiddleName());
		entity.setLastName(model.getLastName());
		entity.setGender(model.getGender());
		entity.setDateOfBirth(model.getDateOfBirth());
		entity.setMobileNumber(model.getMobileNumber());
		entity.setMailId(model.getMailId());
		entity.setWhatsAppNumber(model.getWhatsAppNumber());
		entity.setFaceBookId(model.getFaceBookId());
		if (null != model.getGroupName() && model.getGroupName().trim().length() > 0) {
			entity.setGroup(grpRepo.findByGroupName(model.getGroupName()));
		}

		return entity;
	}

	@Override
	public ContactModel add(ContactModel contact) throws AdbException {
		return valueOf(contactRepo.save(valueOf(contact)));
	}

	@Override
	public ContactModel save(ContactModel contact) throws AdbException {

		ContactModel model = null;

		if (!contactRepo.existsById(contact.getContactId())) {
			throw new AdbException("Contact#" + contact.getContactId() + " not found");
		}

		model = valueOf(contactRepo.save(valueOf(contact)));

		return model;
	}

	@Override
	public void delete(Long contactId) throws AdbException {

		if (!contactRepo.existsById(contactId)) {
			throw new AdbException("Contact#" + contactId + " not found");
		}

		contactRepo.deleteById(contactId);

	}

	@Override
	public ContactModel findById(Long contactId) {
		Optional<ContactEntity> entity = contactRepo.findById(contactId);
		return entity.isPresent() ? valueOf(entity.get()) : null;
	}

	@Override
	public List<ContactModel> findAll() {
		List<ContactModel> models = null;

		List<ContactEntity> entities = contactRepo.findAll();

		if (null != entities && entities.size() > 0) {
			models = new ArrayList<ContactModel>();
			for (ContactEntity entity : entities) {
				models.add(valueOf(entity));
			}
		}

		return models;
	}

	@Override
	public List<GroupStatistics> findGroupCount() {
		return contactRepo.findGroupCount();
	}

}

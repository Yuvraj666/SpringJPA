package com.cg.adb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.adb.exception.AdbException;
import com.cg.adb.model.GroupModel;
import com.cg.adb.model.GroupStatistics;
import com.cg.adb.service.ContactService;
import com.cg.adb.service.GroupService;

@RestController
@RequestMapping("/group")
@CrossOrigin
public class GroupController {
	@Autowired
	private GroupService groupService;

	@Autowired
	private ContactService contactService;

	@GetMapping
	public ResponseEntity<List<GroupModel>> getAllGroups() {
		return new ResponseEntity<List<GroupModel>>(groupService.findAll(), HttpStatus.OK);
	}

	@GetMapping("/{groupId}")
	public ResponseEntity<GroupModel> getGroupById(@PathVariable("groupId") Long groupId) {
		ResponseEntity<GroupModel> result = null;

		GroupModel model = groupService.findById(groupId);

		if (null == model) {
			result = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			result = new ResponseEntity<>(model, HttpStatus.OK);
		}

		return result;
	}

	@GetMapping("/contactCount")
	public ResponseEntity<List<GroupStatistics>> getGroupWiseCounts() {
		return new ResponseEntity<List<GroupStatistics>>(contactService.findGroupCount(), HttpStatus.OK);
	}
	
	@PostMapping
	public ResponseEntity<GroupModel> addGroup(@RequestBody GroupModel group) throws AdbException {
		ResponseEntity<GroupModel> result = null;

		GroupModel model = groupService.add(group);
		result = new ResponseEntity<>(model, HttpStatus.OK);

		return result;
	}

	@PutMapping
	public ResponseEntity<GroupModel> saveGroup(@RequestBody GroupModel group) throws AdbException {
		ResponseEntity<GroupModel> result = null;

		GroupModel model = groupService.save(group);
		result = new ResponseEntity<>(model, HttpStatus.OK);

		return result;
	}

	@DeleteMapping("/{groupId}")
	public ResponseEntity<Void> deleteGroupById(@PathVariable("groupId") Long groupId) throws AdbException {
		groupService.delete(groupId);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	@ExceptionHandler(AdbException.class)
	public ResponseEntity<String> handleAdbException(AdbException exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleException(Exception exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}

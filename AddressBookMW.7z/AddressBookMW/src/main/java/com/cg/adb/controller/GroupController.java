package com.cg.adb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.adb.exception.AdbException;
import com.cg.adb.model.GroupModel;
import com.cg.adb.service.GroupService;

@RestController
@RequestMapping("/group")
public class GroupController {

	private GroupService groupService;

	public GroupService getGroupService() {
		return groupService;
	}

	@Autowired
	public void setGroupService(GroupService groupService) {
		this.groupService = groupService;
	}

	@GetMapping
	public ResponseEntity<List<GroupModel>> getAllGroups() {
		return new ResponseEntity<List<GroupModel>>(groupService.findAll(),HttpStatus.OK);
	}

	@GetMapping("/{groupId}")
	public ResponseEntity<GroupModel> getGroupById(@PathVariable("groupId") Long groupId) {
		ResponseEntity<GroupModel> result = null;

		GroupModel model = groupService.findById(groupId);

		if (null == model) {
			result = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			result = new ResponseEntity<>(model, HttpStatus.OK);
		}

		return result;
	}

	@PostMapping
	public ResponseEntity<?> addGroup(@RequestBody GroupModel group) {
		ResponseEntity<?> result = null;

		GroupModel model;
		try {
			model = groupService.add(group);
			result = new ResponseEntity<>(model, HttpStatus.OK);
		} catch (AdbException exp) {
			result = new ResponseEntity<>(exp.getMessage(), HttpStatus.ALREADY_REPORTED);
		}

		return result;
	}
	
	@PutMapping
	public ResponseEntity<?> saveGroup(@RequestBody GroupModel group) {
		ResponseEntity<?> result = null;

		GroupModel model;
		try {
			model = groupService.save(group);
			result = new ResponseEntity<>(model, HttpStatus.OK);
		} catch (AdbException exp) {
			result = new ResponseEntity<>(exp.getMessage(), HttpStatus.NOT_FOUND);
		}

		return result;
	}
	
	@DeleteMapping("/{groupId}")
	public ResponseEntity<?> deleteGroupById(@PathVariable("groupId") Long groupId) {
		ResponseEntity<?> result = null;

		try {
			groupService.delete(groupId);
		} catch (AdbException exp) {
			result = new ResponseEntity<>(exp.getMessage(), HttpStatus.NOT_FOUND);
		}


		return result;
	}

}

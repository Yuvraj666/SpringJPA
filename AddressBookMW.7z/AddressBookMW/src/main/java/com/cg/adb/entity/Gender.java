package com.cg.adb.entity;

public enum Gender {
	GENT,LADY;
}

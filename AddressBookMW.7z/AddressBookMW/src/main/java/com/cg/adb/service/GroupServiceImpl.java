package com.cg.adb.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import com.cg.adb.dao.GroupRepository;
import com.cg.adb.entity.GroupEntity;
import com.cg.adb.exception.AdbException;
import com.cg.adb.model.GroupModel;

@Service
public class GroupServiceImpl implements GroupService {
	
	@Autowired
	private GroupRepository grpRepo;
		
	@Override
	public GroupModel add(GroupModel group) throws AdbException {
		GroupModel model=null;		
		
		if(grpRepo.existsByGroupName(group.getGroupName())) {
			throw new AdbException("Group already exists");
		}
						
		model = new GroupModel(grpRepo.save(new GroupEntity(group)));
		return model;
	}

	@Override
	public GroupModel save(GroupModel group) throws AdbException{
		GroupModel model=null;		
		
		if(!grpRepo.existsByGroupName(group.getGroupName())) {
			throw new AdbException("Group does not exist");
		}
						
		model = new GroupModel(grpRepo.save(new GroupEntity(group)));
		return model;
	}

	@Override
	public void delete(Long groupId) throws AdbException{
		if(!grpRepo.existsById(groupId)) {
			throw new AdbException("Group does not exist");
		}

		grpRepo.deleteById(groupId);
	}

	@Override
	public GroupModel findById(Long groupId) {
		Optional<GroupEntity> entity = grpRepo.findById(groupId);
		return entity.isPresent()? new GroupModel(entity.get()):null;
	}

	@Override
	public List<GroupModel> findAll() {
		
		List<GroupModel> models=null;
		List<GroupEntity> entities =grpRepo.findAll(); 
		
		if(null!=entities && entities.size()>0) {
			models = new ArrayList<>();
			for(GroupEntity entity : entities) {
				models.add(new GroupModel(entity));
			}
		}
		
		return models;
	}

}
